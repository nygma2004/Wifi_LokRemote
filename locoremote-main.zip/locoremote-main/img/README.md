Supporting images
